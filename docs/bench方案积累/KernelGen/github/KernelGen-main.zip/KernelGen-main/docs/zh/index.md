<!--
 Copyright 2026 FlagOS Contributors

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 -->

# KernelGen 文档中心

```{button-ref} getting_started/getting-started
:ref-type: myst
:color: primary
:class: sd-btn-lg sd-px-4 sd-py-2 sd-fw-bold

快速入门
```

::::{grid} 1 2 2 3
:gutter: 1 1 1 2

:::{grid-item-card} {octicon}`browser;1.5em;sd-mr-1` 产品概述
:link: KernelGen_overview/KernelGen-overview
:link-type: doc

快速了解 KernelGen 及其基本概念。

+++
[了解更多 »](KernelGen_overview/KernelGen-overview)
:::

:::{grid-item-card} {octicon}`book;1.5em;sd-mr-1` Web 平台用户指南
:link: web_user_guide/web-user-guide
:link-type: doc

指导您如何通过 Web 平台使用自然语言提示构建算子定义，最终产出 Kernel。

+++
[了解更多 »](web_user_guide/web-user-guide)
:::

:::{grid-item-card} {octicon}`book;1.5em;sd-mr-1` KernelGen MCP 用户指南
:link: mcp_user_guide/mcp-user-guide
:link-type: doc

指导您如何通过 MCP Server 和工具使用自然语言提示构建算子定义，最终产出 Kernel。

+++
[了解更多 »](mcp_user_guide/mcp-user-guide)
:::

:::{grid-item-card} {octicon}`book;1.5em;sd-mr-1` KernelGen Skills 用户指南
:link: skills_user_guide/skills-user-guide
:link-type: doc

指导您如何通过 Skills 使用自然语言提示构建算子定义，最终产出 Kernel。

+++
[了解更多 »](skills_user_guide/skills-user-guide)
:::

:::{grid-item-card} {octicon}`broadcast;1.5em;sd-mr-1` KernelGen Web 平台使用案例
:link: web_use_case/web-use-case-pr
:link-type: doc

指导您如何将 KernelGen 生成的 Kernel、正确性测例和加速比测例贡献到 FlagGems GitHub。

+++
[了解更多 »](web_use_case/web-use-case-pr)
:::

:::{grid-item-card} {octicon}`broadcast;1.5em;sd-mr-1` KernelGen Skills 使用案例
:link: skills_use_case/skills-use-case
:link-type: doc

指导您如何针对各类场景生成、优化和特化 Kernel。

+++
[了解更多 »](skills_use_case/skills-use-case)
:::

:::{grid-item-card} {octicon}`broadcast;1.5em;sd-mr-1` FAQs
:link: faqs/faqs
:link-type: doc

关于常见问题的信息。

+++
[Learn more »](faqs/faqs)
:::

::::

---

```{toctree}
:caption: 📑 发版说明
:maxdepth: 5
:hidden:

release_notes/release-notes.md
```

```{toctree}
:caption: 📚 用户指南
:maxdepth: 5
:hidden:

KernelGen_overview/KernelGen-overview.md
getting_started/getting-started.md
web_user_guide/web-user-guide.md
mcp_user_guide/mcp-user-guide.md
skills_user_guide/skills-user-guide.md
```

```{toctree}
:caption: ⤵️ 使用案例
:maxdepth: 5
:hidden:

web_use_case/web-use-case-pr.md
skills_use_case/skills-use-case.md
```

```{toctree}
:caption: 📖 FAQs
:maxdepth: 5
:hidden:

faqs/faqs.md
```

```{toctree}
:caption: 📖 参考手册
:maxdepth: 5
:hidden:

references/search-repo-list.md
```
