<!--
 Copyright 2026 FlagOS Contributors

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 -->

# Repository List

KernelGen searches the following GitHub repositories to fetch code snippets similar for your operator definition generation:

- <https://github.com/Abinesh-Mathivanan/triton-kernels>
- <https://github.com/ahitagnied/babygpt>
- <https://github.com/ai-compiler-study/triton-kernels>
- <https://github.com/aiwizzard/learning-triton>
- <https://github.com/alexdremov/kernels>
- <https://github.com/alexzhang13/flashattention2-custom-mask>
- <https://github.com/AlibabaPAI/FLASHNN>
- <https://github.com/ameen-91/custom-triton-kernels>
- <https://github.com/Ascend/triton-ascend>
- <https://github.com/ayoussf/Triton-Hub>
- <https://github.com/besteguney/triton-optitron>
- <https://github.com/bitsandbytes-foundation/bitsandbytes>
- <https://github.com/BobMcDear/attorch>
- <https://github.com/ByteDance-Seed/Triton-distributed>
- <https://github.com/CatManJr/my-kernel-templates>
- <https://github.com/christianazinn/RWKV-Kernels>
- <https://github.com/corl-team/flexsae>
- <https://github.com/daemyung-archive/gpups>
- <https://github.com/daemyung/practice-triton>
- <https://github.com/dame-cell/Triformer>
- <https://github.com/Dao-AILab/quack>
- <https://github.com/Dcas89/crossentropy_triton>
- <https://github.com/debashishc/kernelheim>
- <https://github.com/dropbox/gemlite>
- <https://github.com/dtunai/Tri-RMSNorm>
- <https://github.com/Ekk0hardter/TRITON-Kernel>
- <https://github.com/ELS-RD/kernl>
- <https://github.com/erfanzar/ejkernel>
- <https://github.com/facebookexperimental/triton>
- <https://github.com/fattorib/fusedswiglu>
- <https://github.com/fla-org/flash-linear-attention>
- <https://github.com/fla-org/native-sparse-attention>
- <https://github.com/FlagOpen/FlagGems>
- <https://github.com/foundation-model-stack/foundation-model-stack>
- <https://github.com/foundation-model-stack/vllm-triton-backend>
- <https://github.com/fpgaminer/GPTQ-triton>
- <https://github.com/fulvius31/triton-cache-tracker>
- <https://github.com/gpu-mode/resource-stream>
- <https://github.com/gpu-mode/triton-index>
- <https://github.com/HazyResearch/ThunderKittens>
- <https://github.com/IaroslavElistratov/triton-autodiff>
- <https://github.com/IBM/qattn>
- <https://github.com/IBM/triton-dejavu>
- <https://github.com/IntelLabs/EquiTriton>
- <https://github.com/jax-ml/jax-triton>
- <https://github.com/jmakishimu/sparse-gemma>
- <https://github.com/JonasGeiping/linear_cross_entropy_loss>
- <https://github.com/kakaobrain/trident>
- <https://github.com/kyegomez/Astra>
- <https://github.com/kyegomez/FlashAttention20Triton>
- <https://github.com/kyleliang919/triton_kernels>
- <https://github.com/lessw2020/triton_kernels_for_fun_and_profit>
- <https://github.com/loreloc/triturus>
- <https://github.com/lucidrains/triton-transformer>
- <https://github.com/lygztq/triton-kernels>
- <https://github.com/meta-recsys/generative-recommenders>
- <https://github.com/meta-recsys/triton-aot>
- <https://github.com/mgmalek/efficient_cross_entropy>
- <https://github.com/michael-diggin/triton-kernels>
- <https://github.com/milad2073/open-deep-kernel>
- <https://github.com/niconunezz/triton-kernels>
- <https://github.com/nscottnichols/triton_vector_add_example_with_named_kernels>
- <https://github.com/NVlabs/Sana>
- <https://github.com/open-lm-engine/accelerated-model-architectures>
- <https://github.com/opendilab/DI-hpc>
- <https://github.com/prtk1729/gpu-kernel-programming-triton>
- <https://github.com/redhat-et/triton-dev-containers>
- <https://github.com/rickyxie2004/Customize-Block-Sparse-Attention-with-Triton>
- <https://github.com/RiseAI-Sys/attention-gym>
- <https://github.com/RobertCsordas/moe_layer>
- <https://github.com/ROCm/hipify_torch>
- <https://github.com/ROCm/aiter>
- <https://github.com/ROCm/aotriton>
- <https://github.com/ROCm/tritonBLAS>
- <https://github.com/RPegoud/Triton-Kernels>
- <https://github.com/Sachin-Bharadwaj/Triton-Kernels>
- <https://github.com/SamuelStentz/triton-kernels>
- <https://github.com/sanket-pixel/triton-swiglu>
- <https://github.com/shawntan/scattermoe>
- <https://github.com/SiriusNEO/Triton-Puzzles-Lite>
- <https://github.com/srush/Triton-Puzzles>
- <https://github.com/stackav-oss/conch>
- <https://github.com/stanford-futuredata/stk>
- <https://github.com/sublinear-systems/triton-utils>
- <https://github.com/tamhonvotri/Wuzi-Attention>
- <https://github.com/thevasudevgupta/gpt-triton>
- <https://github.com/thunlp/TritonBench>
- <https://github.com/timudk/flux_triton>
- <https://github.com/toyaix/TritonLLM>
- <https://github.com/triton-lang/triton>
- <https://github.com/unslothai/unsloth>
- <https://github.com/VeriSilicon/triton-vsi-backend>
- <https://github.com/Viditnegi/Flash_Attention_w_Triton>
- <https://github.com/VisharadR/Mini-Transformer---GPU-optimized>
- <https://github.com/vivekvkashyap/triton_gpt2>
- <https://github.com/vllm-project/vllm>
- <https://github.com/wa008/Triton-fused-kernel>
- <https://github.com/waqar-sheikh/cuda-triton-kernels>
- <https://github.com/Wheest/triton_samples>
- <https://github.com/XunhaoLai/native-sparse-attention-triton>
- <https://github.com/yuekaizhang/Triton-OpenAI-Speech>
- <https://github.com/Zen-Sherbert/Proteus-Attention>
